---
layout: layouts/base.njk
title: About
templateClass: tmpl-post
eleventyNavigation:
  key: About
  order: 3
---

I am a person that writes stuff.

This blog template is based on [eleventy-high-performance-blog](https://www.industrialempathy.com/posts/eleventy-high-performance-blog/) which itself is based on [eleventy-base-blog](https://github.com/11ty/eleventy-base-blog).
